﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using ProjetInfo;

namespace TestUnitaireDictionnaire
{
    [TestClass]
    public class UnitTest1
    {
        //Initialisation de la variable Dictionnaire
        Dictionnaire dicoFR = new Dictionnaire(new List<List<string>> { new List<string> { "mot1", "mot2" }, new List<string> { "mot11", "mot12" } }, "français");

        [TestMethod]
        //Test unitaire de la méthode RechDichoRecursif
        public void RechDichoRecursifTest()
        {
            Assert.AreEqual(dicoFR.RechDichoRecursif("mot11"),true);
        }
    }
}

