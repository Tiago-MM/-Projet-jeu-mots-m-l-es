﻿using System;
namespace ProjetInfo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Jeu.Play();// Pour jouer :)
        }
    }
}
