﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjetInfo;

namespace TestUnitaireMot
{
    [TestClass]
    public class UnitTest1
    {
        //Initialisation de la variable Mot 
        Mot mot1 = new Mot("HOMME", "N", 3, 9);
        [TestMethod]
        //Test unitaire pour la méthode Equals
        public void EqualsTest()
        {
            Assert.AreEqual(mot1.Equals(mot1), true);
        }
    }
}

