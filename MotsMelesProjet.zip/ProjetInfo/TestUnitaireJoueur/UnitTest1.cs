﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjetInfo;

namespace TestUnitaireJoueur
{
    [TestClass]
    public class UnitTest1
    {
        //Variable Pierre Joueur
        Joueur Pierre = new Joueur("Pierre", new List<string> { "coucou" }, 10);
        [TestMethod()]
        //Test unitaire pour la méthode Add_Score
        public void Add_ScoreTest()
        {
            Pierre.Add_Score(5);
            Assert.AreEqual(Pierre.Score, 15);
        }
        [TestMethod()]
        //Test unitaire pour la méthode Add_Mot
        public void Add_MotTest()
        {
            Pierre.Add_Mot("salut");
            Assert.AreEqual(Pierre.Nbmot[1], "salut");
        }
        [TestMethod()]
        //Test unitaire pour la méthode toString
        public void toStringTest()
        {
            Assert.AreEqual(("Nom: " + Pierre.Nom + "\n" + "Nombre de mot trouvé: " + Pierre.Nbmot.Count + "\n" + "Score actuel : " + Pierre.Score), Pierre.toString());
        }
    }
}

